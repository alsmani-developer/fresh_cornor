<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiscountsQuantity extends Model
{
    protected $table = 'discounts_quantity';
    public $timestamps  = false;
    protected $guarded=[];
}
