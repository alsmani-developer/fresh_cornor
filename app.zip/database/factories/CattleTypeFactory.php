<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CattleType;
use Faker\Generator as Faker;

$factory->define(CattleType::class, function (Faker $faker) {
    return [
        //
    ];
});
