<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CattlesOrigin extends Model
{
    public $timestamps  = false;
    protected $guarded=[];
}
