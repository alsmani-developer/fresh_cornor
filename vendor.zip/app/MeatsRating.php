<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MeatsRating extends Model
{
    //
    public $timestamps = false;
}
