<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MeatsShape extends Model
{
    public $timestamps  = false;
    protected $guarded=[];
}
