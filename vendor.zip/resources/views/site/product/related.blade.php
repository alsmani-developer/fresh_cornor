<!-- Section -->
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">

            @include('site.product.demo1')

        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<!-- /Section -->