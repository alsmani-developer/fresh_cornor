changes 
product product.php, cart index, checkout index, CheckoutController, product product.php, 
style.css,rtl-style.css,  OrderMeatsDiscount, orders.blade.php, header, checkout index.blade.php