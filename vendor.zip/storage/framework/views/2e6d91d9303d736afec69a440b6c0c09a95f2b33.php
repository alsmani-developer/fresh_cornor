<?php echo $__env->make('site.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title><?php echo $__env->yieldContent('page-title'); ?> | <?php echo e(config('app.name')); ?></title>
</head>
<body>
    <?php echo $__env->make('site.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('slider'); ?>
    <div class="container">
    <div id="app">
        <main class="py-4">
            
            <?php if(session()->has('error')): ?>
                <div class="row">
                    <div class="col-md-12 text-center alert alert-danger h4 font-weight-bold">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
                <div class="row">
                    <div class="col-md-12 text-center alert alert-success h4 font-weight-bold">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    </div>
    <?php echo $__env->make('site.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/site/layouts/app.blade.php ENDPATH**/ ?>