<?php $__env->startSection('content'); ?>

<div class="card card-outline card-info" style="margin-top:-5%;">
  
    <div class="card-header">
      
     
      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-card-widget="collapse">
          <i class="fas fa-minus"></i>
        </button>
        <button type="button" class="btn btn-tool" data-card-widget="remove">
          <i class="fas fa-times"></i>
        </button>
      </div>
      
      <users-component v-bind:routes = " { 
          users : '<?php echo e(route('get_users')); ?>',
          add_user :'<?php echo e(route('user_register')); ?>',
          edit_user : '<?php echo e(route('user_update')); ?>',
          deActivate : '<?php echo e(route('de_activate')); ?>',
          activate : '<?php echo e(route('activate')); ?>',
          } "    
      >
      </users-component>
      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/vendor/multiauth/admin/pages/users.blade.php ENDPATH**/ ?>