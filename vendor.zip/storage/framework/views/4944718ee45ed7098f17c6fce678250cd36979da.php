<!-- HEADER -->
<header>
    <!-- TOP HEADER -->
    <div id="top-header">
        <div class="container">
            <ul class="header-links pull-left">
                <li><a href="#"><i class="fa fa-phone"></i> +021-95-51-84</a></li>
                <li><a href="#"><i class="fa fa-envelope-o"></i> email@email.com</a></li>
                <li><a href="#"><i class="fa fa-map-marker"></i> 1734 Stonecoal Road</a></li>
            </ul>
            <ul class="header-links pull-right">
                <?php if(!Auth::check()): ?>
                <li><a href="/login"><i class="fa fa-user-o"></i> 
                    <?php echo e(trans('sentence.Login')); ?>

                </a></li>
                <li><a href="/register"><i class="fa fa-registered"></i> 
                    <?php echo e(trans('sentence.Register')); ?>

                </a></li>
                    <?php else: ?> 
                    <li>
                    <a href="<?php echo e(route('account.orders')); ?>" class="text-info">
                    <?php echo e(trans('sentence.Orders')); ?></a>
                    <i class="fa fa-bookmark text-info"></i>
                    </li>
                    <li><a href="<?php echo e(route('userProfile')); ?>">
                        <?php echo e(trans('sentence.Profile')); ?>

                        <img src="<?php echo e(asset('profile/defualt.png')); ?>" alt="<?php echo e(Auth::user()->name); ?>" width="20" height="20">
                    </a></li>
                    <li class="rtl-text-right mr-3"><a href="/logout">
                        <i class="fa fa-sign-out"></i>
                        <?php echo e(trans('sentence.LogOut')); ?>

                    </a></li>
                    <?php endif; ?>
                <li><a href="/change-lang/eng">
                    English
                    </a>
                    |
                </li> 
                <li><a href="/change-lang/ar">
                    العربية
                    </a>
                </li> 
            </ul>
        </div>
    </div>
    <!-- /TOP HEADER -->

    <!-- MAIN HEADER -->
    <div id="header">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <!-- LOGO -->
                <div class="col-md-3">
                    <div class="header-logo">
                        <a href="/" class="logo text-light">
                            <h3 class="text-light">
                               <span class="text-red">F</span>resh <span class="text-red">C</span>ornor
                            </h3>
                        </a>
                    </div>
                </div>
                <!-- /LOGO -->

                <!-- SEARCH BAR -->
                <div class="col-md-5">
                    <div class="header-search">
                        <form method="GET" action="<?php echo e(route('products.search-result')); ?>">
                            <?php echo csrf_field(); ?>
                            
                            <input class="input" placeholder="<?php echo e(trans('sentence.Search Here')); ?>" 
                            name="search_text">
                            <button class="search-btn" type="submit">
                                <?php echo e(trans('sentence.Search')); ?>

                            </button>
                        </form>
                        <button class="text-white cursor-pointer small adv_search_btn" id="adv_search_btn">
                            <?php echo e(trans('sentence.Advanced Search')); ?>

                        </button>
                    </div> 
                </div>
                <!-- /SEARCH BAR -->

                <!-- ACCOUNT -->
                <div class="col-md-4 clearfix">
                    <div class="header-ctn">
                         <!-- Notification -->
                         <div class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <i class="fa fa-exclamation-circle "></i>
                                <span>
                                    <?php echo e(trans('sentence.Notification')); ?>

                                </span>
                                <div class="qty">3</div>
                            </a>
                            <div class="cart-dropdown">
                                <div class="cart-list">
                                    <div class="product-widget">
                                        <div class="product-img">
                                            <img src="./img/product01.png" alt="">
                                        </div>
                                        <div class="product-body">
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price"><span class="qty">1x</span>$980.00</h4>
                                        </div>
                                        <button class="delete"><i class="fa fa-close"></i></button>
                                    </div>

                                    <div class="product-widget">
                                        <div class="product-img">
                                            <img src="./img/product02.png" alt="">
                                        </div>
                                        <div class="product-body">
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price"><span class="qty">3x</span>$980.00</h4>
                                        </div>
                                        <button class="delete"><i class="fa fa-close"></i></button>
                                    </div>
                                </div>
                                <div class="cart-summary">
                                    <small>3 Item(s) selected</small>
                                    <h5>SUBTOTAL: $2940.00</h5>
                                </div>
                                <div class="cart-btns">
                                    <a href="#">View Cart</a>
                                    <a href="#">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- /Notification -->
                        <!-- Wishlist -->
                        <div>
                            <a href="<?php echo e(route('userProfile')); ?>">
                                <i class="fa fa-heart-o"></i>
                                <span><?php echo e(trans('sentence.Your Wishlist')); ?></span>
                                <div class="qty">
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php echo e(Auth::user()->favorites->count()); ?>

                                        <?php else: ?> 
                                        0
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                        <!-- /Wishlist -->

                        <!-- Cart -->
                        <div class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <i class="fa fa-shopping-cart"></i>
                                <span>
                                    <?php echo e(trans('sentence.Your Cart')); ?>

                                </span>
                                <div class="qty">
                                    <?php echo e($cartCount); ?>

                                </div>
                            </a>
                            <div class="cart-dropdown">
                                <?php if(\Cart::isEmpty()): ?>
                                <p class="alert alert-warning">Your shopping cart is empty.</p>
                                <?php else: ?>
                                <div class="cart-list">
                                    <?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product-widget rtl-text-right">
                                        <div class="product-img">
                                            <img src="<?php echo e($item->attributes->pic); ?>" alt="">
                                        </div>
                                        <div class="product-body mr-2">
                                            <h3 class="product-name">
                                            <a href="/product/<?php echo e($item->attributes->productId); ?>">
                                                <?php echo e($item->name); ?>    
                                            </a>
                                            </h3>
                                            <h4 class="product-price text-success">
                                                <?php echo e(trans('sentence.Price')); ?>:
                                                <?php echo e($item->price); ?>

                                                <?php echo e(trans('sentence.Rial  For KG')); ?>

                                            </h4>
                                            <h4 class="product-price text-info">
                                                <?php echo e(trans('sentence.Quantity')); ?>:
                                                <?php echo e($item->quantity); ?>

                                                <?php echo e(trans('sentence.KG')); ?>

                                            </h4>
                                        </div>
                                        <a href="<?php echo e(route('checkout.cart.remove', $item->id)); ?>" class="delete"><i class="fa fa-close"></i></a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="cart-summary rtl-text-right">
                                    <small><?php echo e(\Cart::getContent()->count()); ?> <?php echo e(trans('sentence.Item(s) selected')); ?></small>
                                    <h5 class="text-success"><?php echo e(trans('sentence.Total')); ?>: <?php echo e(\Cart::getSubTotal()); ?> <?php echo e(trans('sentence.Rial')); ?></h5>
                                </div>
                                <div class="cart-btns">
                                    <a href="/cart">
                                    <?php echo e(trans('sentence.View Cart')); ?>

                                    </a>
                                    <a href="<?php echo e(route('checkout.index')); ?>">
                                        <?php echo e(trans('sentence.Checkout')); ?>  <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <!-- /Cart -->

                        <!-- Menu Toogle -->
                        <div class="menu-toggle">
                            <a href="#">
                                <i class="fa fa-bars"></i>
                                <span>Menu</span>
                            </a>
                        </div>
                        <!-- /Menu Toogle -->
                    </div>
                </div>
                <!-- /ACCOUNT -->
            </div>
            <!-- row -->
        </div>
        <!-- container -->
    </div>
    <!-- /MAIN HEADER -->
</header>
<!-- /HEADER -->
<form class="jumbotron d-none" id="adv_search_form" action="<?php echo e(route('products.adv-search-result')); ?>" method="GET">
    <div class="container" dir="rtl" style="margin-left:11%">
        <div class="row w-100" id="search">
                <div class="form-group col-xs-2 pr-0">
                    <button type="submit" class="btn btn-block btn-info w-100">
                        <?php echo e(trans('sentence.Search')); ?>

                    </button>
                </div>
                <div class="form-group col-xs-10 pl-0">
                    <input class="form-control" type="text" 
                    placeholder="<?php echo e(trans('sentence.Search')); ?>" name="name"/>
                </div>
        </div>
        <div class="row w-100" id="filter">
            
                <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="make" class="filter-make filter form-control" name="cattels_types_id">
                        <option value="">
                            <?php echo e(trans('sentence.Category')); ?>

                        </option>
                        <?php $__currentLoopData = $CattlesType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>">
                            <?php echo e($locale == 'ar' ? $type->ar_name : $type->en_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="model" class="filter-model filter form-control" name="cattles_origins_id">
                        <option value=""><?php echo e(trans('sentence.Country')); ?></option>
                        <?php $__empty_1 = true; $__currentLoopData = $CattlesOrigins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CattlesOrigin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($CattlesOrigin->id); ?>">
                            <?php echo e($locale == 'ar' ? $CattlesOrigin->ar_name : $CattlesOrigin->en_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="type" class="filter-type filter form-control" name="meats_areas_id">
                        <option value=""><?php echo e(trans('sentence.Meats Areas')); ?></option>
                        <?php $__empty_1 = true; $__currentLoopData = $MeatsAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MeatsArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($MeatsArea->id); ?>">
                            <?php echo e($locale == 'ar' ? $MeatsArea->ar_name : $MeatsArea->en_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="price" class="filter-price filter form-control" name="meats_shapes_id">
                        <option value="">
                        <?php echo e(trans('sentence.Meats Shape')); ?>

                        </option>
                        <?php $__empty_1 = true; $__currentLoopData = $MeatsShapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MeatsShape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($MeatsShape->id); ?>">
                            <?php echo e($locale == 'ar' ? $MeatsShape->ar_name : $MeatsShape->en_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </select>
                </div>
                
        </div>
        </div>
    </form>

    <script>
        $(document).ready(function(){
            $("#adv_search_btn").on('click', function(){
                $("#adv_search_form").toggle(200);
            });
        });
    </script><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/site/inc/header.blade.php ENDPATH**/ ?>