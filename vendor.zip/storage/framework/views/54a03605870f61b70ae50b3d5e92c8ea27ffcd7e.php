<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">القطاعات</h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
               
            </div>
            <div class="card-body " aria-expanded="true" >
                <div class="card-block card-dashboard">

					<a  class="btn btn-lg btn-primary  pull-left AddSector" style="margin-bottom: 10px; margin-top: -10px; color: white;" data-toggle="modal" data-target="#AddSector">اضافة فئة</a>
				
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>اسم الفئة </th>
                                   
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                           <?php
                              $count=0; 
                           ?>
                                <?php $__empty_1 = true; $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th scope="row"><?php echo e(++$count); ?></th>
                                    <td><?php echo e($field->name); ?></td>
                                  
									<td>
                                        <form  action="<?php echo e(route('field.destroy',[$field->id])); ?>" method="post" >
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('delete')); ?>

										<button type="submit" data-toggle="tooltip" class="btn btn-link btn-lg" data-original-title="حذف" onclick="return confirm('Are you sure you want to delete this item?');">
											<a ><i class="icon-trash-o" style=" font-size:2rem; color: #0c8ed3;"></i></a>
											</button>
                                        </form>
                                        <form  action="" method="post" style="width='80'">
                                            <?php echo csrf_field(); ?>
										<button type="button" data-toggle="tooltip" class="btn btn-link btn-lg" data-original-title="تعديل" >
											<a href=""><i class="icon-edit2" style=" font-size:2rem ; color: #0c8ed3;"></i></a>
                                            </button>
                                        </form>
									</td>
								</tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr></tr>
                                <?php endif; ?>
                                
								
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.mainlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alsamni\Desktop\veen\resources\views/pages/field.blade.php ENDPATH**/ ?>