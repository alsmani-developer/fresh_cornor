<!doctype html>
<html lang="<?php echo e($locale); ?>">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/site/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site/nouislider.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site/slick-theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site/style.css')); ?>">
    <?php if($locale == 'ar'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/site/style-rtl.css')); ?>">
    <?php endif; ?>
    <link rel="shortcut icon" type="image/webp" href="<?php echo e(asset('images/logo.jpg')); ?>">
    <link rel="apple-touch-icon"  href="<?php echo e(asset('images/logo.jpg')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="mobile-web-app-capable" content="yes">
	<meta property="og:type" content="website" />
	<meta property="og:site_name" content="<?php echo e(config('app.name')); ?>">
    <meta name="theme-color" content="#191A21">
    <script src="<?php echo e(asset('js/site/jquery.min.js')); ?>"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/site/inc/head.blade.php ENDPATH**/ ?>