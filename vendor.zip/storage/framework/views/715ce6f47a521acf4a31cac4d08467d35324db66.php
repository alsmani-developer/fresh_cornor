<?php $__env->startSection('content'); ?>
<example-component></example-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/vendor/multiauth/admin/home.blade.php ENDPATH**/ ?>