<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">الأنواع</h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
               
            </div>
            <div class="card-body " aria-expanded="true" >
                <div class="card-block card-dashboard">

					<a  class="btn btn-lg btn-primary  pull-left AddType" style="margin-bottom: 10px; margin-top: -10px; color: white;" data-toggle="modal" data-target="#AddType">اضافة نوع</a>
				
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>اسم النوع </th>
                                   
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                           
                            
                                <tr>
                                    <th scope="row">3</th>
                                    <td>Larry</td>
                                  
									<td>
										<button type="button" data-toggle="tooltip" class="btn btn-link btn-lg" data-original-title="حذف">
											<a href=""><i class="icon-trash-o" style=" font-size:2rem; color: #0c8ed3;"></i></a>
											</button>
								   
										<button type="button" data-toggle="tooltip" class="btn btn-link btn-lg" data-original-title="تعديل">
											<a href=""><i class="icon-edit2" style=" font-size:2rem ; color: #0c8ed3;"></i></a>
											</button>
									</td>
								</tr>
								
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.mainlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alsamni\Desktop\veen\resources\views/pages/types.blade.php ENDPATH**/ ?>