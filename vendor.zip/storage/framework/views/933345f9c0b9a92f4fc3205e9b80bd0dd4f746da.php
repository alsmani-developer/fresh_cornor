<?php $__env->startSection('content'); ?>

<div class="card card-outline card-info" style="margin-top:-5%;">
  
    <div class="card-header">
      
     
      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-card-widget="collapse">
          <i class="fas fa-minus"></i>
        </button>
        <button type="button" class="btn btn-tool" data-card-widget="remove">
          <i class="fas fa-times"></i>
        </button>
      </div>
      
      <origin-component v-bind:routes = " {
          get : '<?php echo e(route('origin.index')); ?>',
          post : '<?php echo e(route('origin.store')); ?>',
          } "    
      >
      </origin-component>
      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/vendor/multiauth/admin/pages/cattle_origin.blade.php ENDPATH**/ ?>