<?php $__env->startSection('content'); ?>

<div class="card card-outline card-info" style="margin-top:-5%;">
  
    <div class="card-header">
      
     
      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-card-widget="collapse">
          <i class="fas fa-minus"></i>
        </button>
        <button type="button" class="btn btn-tool" data-card-widget="remove">
          <i class="fas fa-times"></i>
        </button>
      </div>
      
      <meat-component v-bind:routes = " {
          get : '<?php echo e(route('meat.index')); ?>',
          post : '<?php echo e(route('meat.store')); ?>',
          shape : '<?php echo e(route('get_shape')); ?>',
          type : '<?php echo e(route('get_type')); ?>',
          origin : '<?php echo e(route('get_origin')); ?>',
          area : '<?php echo e(route('get_area')); ?>',
          upload_image:'<?php echo e(route('upload_img')); ?>',
          deActivate : '<?php echo e(route('de_activate')); ?>',
          activate : '<?php echo e(route('activate')); ?>',
          } "    
      >
      </meat-component>
      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/vendor/multiauth/admin/pages/meats.blade.php ENDPATH**/ ?>