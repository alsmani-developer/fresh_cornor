<!-- SECTION -->
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <!-- section title -->
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3 class="title">
                        <?php echo e(trans('sentence.Discount And Offers')); ?>

                    </h3>
                </div>
            </div>
            <!-- /section title -->

            <?php $__empty_1 = true; $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                 <!-- shop -->
            <div class="col-md-4 col-xs-6 rtl-float-right">
                <div class="shop">
                    <div class="shop-img">
                        <img src="<?php echo e(asset('images/'.$discount->pic)); ?>" 
                        alt="<?php echo e($locale === 'ar' ?  $discount->ar_name : $discount->en_name); ?>" height="240">
                    </div>
                    <div class="shop-body">
                        <h3> 
                            <?php echo e($locale === 'ar' ?  $discount->ar_name : $discount->en_name); ?>

                        </h3>
                        <p class="text-light">
                            <?php echo e($locale === 'ar' ?  mb_substr($discount->ar_description, 0, 30) :
                             mb_substr($discount->en_description, 0, 30)); ?>

                        </p>
                        <a href="/discount/<?php echo e($discount->id); ?>" class="cta-btn"> 
                            <?php echo e(trans('sentence.More')); ?> <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            </div>
            <!-- /shop -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<!-- /SECTION --><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/site/home/category.blade.php ENDPATH**/ ?>