<!-- NAVIGATION -->
<nav id="navigation">
    <!-- container -->
    <div class="container">
        <!-- responsive-nav -->
        <div id="responsive-nav">
            <ul class="main-nav nav navbar-nav" dir="rtl">
                <?php if(session()->get('locale') == 'eng'): ?>
                <li class="<?php echo e(empty(Request::segment(1)) ? 'active ' : null); ?>"><a href="/">
                    <?php echo e(trans('sentence.Home Page')); ?>    
                    </a>
                    </li>
                    <li class="<?php echo e(Request::segment(1) === 'products' ? 'active ' : null); ?>">
                        <a href="/products">
                        <?php echo e(trans('sentence.All Products')); ?>    
                        </a>
                        </li>
                    <li class="<?php echo e(Request::segment(1) === 'discounts' ? 'active ' : null); ?>">
                        <a href="/discounts">
                        <?php echo e(trans('sentence.Discount And Offers')); ?>    
                    </a></li>
                    <?php $__currentLoopData = $CattlesType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CattleType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="<?php echo e(Request::segment(2) === $CattleType->id ? 'active ' : null); ?>">
                        <a href="/category/<?php echo e($CattleType->id); ?>">
                            <?php echo e($CattleType->en_name); ?>

                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class=""><a href="#">
                            <?php echo e(trans('sentence.Products Delivery')); ?>    
                            </a>
                            </li>
                            <li class=""><a href="#">
                            <?php echo e(trans('sentence.Payment Methods')); ?>    
                            </a>
                            </li>
                <?php else: ?>
                        <li class="">
                        <a href="#">
                        <?php echo e(trans('sentence.Products Delivery')); ?>    
                        </a>
                        </li>
                        <li class=""><a href="#">
                        <?php echo e(trans('sentence.Payment Methods')); ?>    
                        </a>
                        </li>
                        <?php $__currentLoopData = $CattlesType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CattleType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e(Request::segment(2) === $CattleType->id ? 'active ' : null); ?>">
                            <a href="/category/<?php echo e($CattleType->id); ?>">
                                <?php echo e($CattleType->ar_name); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e(Request::segment(1) === 'discounts' ? 'active ' : null); ?>">
                            <a href="/discounts">
                            <?php echo e(trans('sentence.Discount And Offers')); ?>    
                        </a></li>
                        <li class="<?php echo e(Request::segment(1) === 'products' ? 'active ' : null); ?>"><a href="/products">
                            <?php echo e(trans('sentence.All Products')); ?>    
                            </a>
                            </li>
                        <li class="<?php echo e(empty(Request::segment(1)) ? 'active ' : null); ?>"><a href="/">
                            <?php echo e(trans('sentence.Home Page')); ?>    
                            </a>
                            </li>
                            
                <?php endif; ?>
                
            </ul>
            <!-- /NAV -->
        </div>
        <!-- /responsive-nav -->
    </div>
    <!-- /container -->
</nav>
<!-- /NAVIGATION --><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/site/inc/nav.blade.php ENDPATH**/ ?>