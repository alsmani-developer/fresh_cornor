<!-- SECTION -->
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">

            <!-- section title -->
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3 class="title">
                        <?php echo e(trans('sentence.New Products')); ?>

                    </h3>
                </div>
            </div>
            <!-- /section title -->

            <!-- Products tab & slick -->
            <div class="col-md-12">
                <div class="row">
                    <div class="products-tabs">
                        <!-- tab -->
                        <div id="tab1" class="tab-pane active">
                            <div class="products-slick" data-nav="#slick-nav-1">
                                <?php $__empty_1 = true; $__currentLoopData = $get_meats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get_meat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                
                                    <!-- product -->
                                <div class="product">
                                    <a href="/product/<?php echo e($get_meat->id); ?>" 
                                        title="<?php echo e($locale === 'ar' ?  $get_meat->ar_name : $get_meat->en_name); ?>">
                                    <div class="product-img">
                                        <img src="<?php echo e(asset('images/'.$get_meat->pic)); ?>" 
                                        alt="<?php echo e($locale === 'ar' ?  $get_meat->ar_name : $get_meat->en_name); ?>">
                                        <?php if(isset($get_meat->discount_meat->last()->discount->amount)): ?>
                                        <div class="product-label">
                                            <span class="sale">
                                                <?php echo e($get_meat->discount_meat->last()->discount->amount); ?>%
                                            </span>
                                        </div> 
                                        <?php endif; ?>
                                        
                                        <div class="product-label-contity">
                                            <?php if($get_meat->stock !=null): ?>
                                            <span class="<?php echo e($get_meat->stock->quantity > 
                                            0 ? 'available' : 'not_available'); ?>">
                                                     <?php echo e($get_meat->stock->quantity > 0 ? 
                                                     trans('sentence.Available')  : 
                                                     trans('sentence.Not Available')); ?>

                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    </a>
                                    <div class="product-body" title="">
                                        <p class="product-category">
                                            <?php echo e($locale == 'ar' ? $get_meat->cattlesType->ar_name :
                                            $get_meat->cattlesType->en_name); ?> 
                                        </p>
                                        <h3 class="product-name">
                                            <a href="/product/<?php echo e($get_meat->id); ?>">
                                            <?php echo e($locale === 'ar' ?  $get_meat->ar_name : $get_meat->en_name); ?>

                                            </a>
                                        </h3>

                                         <h4 class="product-price" dir="rtl"> 
                                             <?php if(isset($get_meat->discount_meat->last()->discount->amount)): ?>
                                             <del class="text-divider">
                                                <span class="float-left">
                                                    <?php echo e(trans('sentence.Rial')); ?>

                                                    <?php echo e(trans('sentence.KG')); ?>

                                                </span>
                                                <?php echo e($get_meat->stock->price); ?>

                                            </del> <br>
                                            <?php
                                            ?>
                                            </h4>
                                            <h4 class="product-price text-success" dir="rtl">
                                                <?php echo e($get_meat->stock->price - 
                                                $get_meat->discount_meat->last()->discount->amount
                                                 / ($get_meat->stock->price * 100)); ?>

                                             <span class="float-left">
                                                <?php echo e(trans('sentence.Rial')); ?>

                                                <?php echo e(trans('sentence.KG')); ?>

                                             </span>
                                            </h4>
                                            <?php else: ?> 
                                            <h4 class="product-price text-success" dir="rtl">
                                                <?php if($get_meat->stock !=null): ?>  <?php echo e($get_meat->stock->price); ?> <?php endif; ?>
                                             <span class="float-left">
                                                <?php echo e(trans('sentence.Rial')); ?>

                                                <?php echo e(trans('sentence.KG')); ?>

                                             </span>
                                            </h4>
                                             <?php endif; ?>
                                        <div class="product-rating">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= round($get_meat->meatsrating->avg('ratting'))): ?>
                                                <?php
                                                $color = 'text-danger';
                                                ?>
                                                <?php else: ?>
                                                <?php
                                                $color = 'text-divider';
                                                ?>
                                                <?php endif; ?>
                                                <i class="fa fa-star <?php echo e($color); ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <form class="product-btns" action="<?php echo e(route('addToFav', $get_meat->id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                           <button class="add-to-wishlist" type="submit">
                                               <i class="fa fa-heart-o"></i><span class="tooltipp">
                                               <?php echo e(trans('sentence.add to wishlist')); ?></span>
                                           </button>
                                       <button class="quick-view"><i class="fa fa-eye"></i>
                                           <p class="tooltipp" dir="<?php echo e($locale == 'ar' ? 'rtl' : 'ltl'); ?>"> 
                                               <?php echo e($get_meat->views); ?>

                                               <?php echo e(trans('sentence.views')); ?>

                                               </p>
                                           </button>
                                       </form>
                                    </div>
                                </div>
                                <!-- /product -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                            </div>
                            <div id="slick-nav-1" class="products-slick-nav"></div>
                        </div>
                        <!-- /tab -->
                    </div>
                </div>
            </div>
            <!-- Products tab & slick -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<!-- /SECTION --><?php /**PATH C:\Users\Alsamni\Desktop\project\fresh_corner\resources\views/site/home/demo1.blade.php ENDPATH**/ ?>